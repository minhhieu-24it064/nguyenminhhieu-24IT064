package bai10;

public class bai10 {

}
